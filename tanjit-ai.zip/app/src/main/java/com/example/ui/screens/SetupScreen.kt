package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AssistantSettings
import com.example.data.PermissionSummary
import com.example.data.VoiceProfile
import com.example.ui.theme.BorderViolet
import com.example.ui.theme.CardObsidian
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepPurple
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElevatedObsidian
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.PlasmaGlow
import com.example.ui.theme.SuccessMint
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidBlack
import com.example.ui.theme.WarningAmber

@Composable
fun SetupScreen(
    permissionSummary: PermissionSummary,
    settings: AssistantSettings,
    activeVoiceLabel: String,
    isBengaliVoiceMissing: Boolean,
    availableVoices: List<VoiceProfile>,
    onPermissionsUpdated: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onSelectDialect: (String) -> Unit,
    onPitchChange: (Float) -> Unit,
    onRateChange: (Float) -> Unit,
    onSelectVoice: (String) -> Unit,
    onTestMaleVoice: () -> Unit,
    onOpenTtsSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val multiPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onPermissionsUpdated()
    }

    val allEssentialPermissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            add(Manifest.permission.ANSWER_PHONE_CALLS)
        }
        add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(VoidBlack, ObsidianSurface, VoidBlack))),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "SETUP & VOICE",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PlasmaGlow
                    )
                    Text(
                        text = "সহজ অনুমতি সেটআপ এবং পুরুষ বাংলা ভয়েস ক্যালিব্রেশন",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            // Simple One-Tap Permission Progress Card
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = CardObsidian,
                    border = BorderStroke(
                        1.dp,
                        if (permissionSummary.allGranted) SuccessMint.copy(alpha = 0.65f)
                        else ElectricPurple.copy(alpha = 0.7f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "অনুমতি সেটআপ (${permissionSummary.grantedCount}/${permissionSummary.totalCount})",
                                style = MaterialTheme.typography.titleMedium,
                                color = PlasmaGlow
                            )
                            Text(
                                text = if (permissionSummary.allGranted) "সম্পন্ন" else "প্রয়োজনীয়",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (permissionSummary.allGranted) SuccessMint else CyberCyan
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = {
                                permissionSummary.grantedCount.toFloat() / permissionSummary.totalCount.toFloat()
                            },
                            color = if (permissionSummary.allGranted) SuccessMint else ElectricPurple,
                            trackColor = ElevatedObsidian,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { multiPermissionLauncher.launch(allEssentialPermissions) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricPurple,
                                    contentColor = VoidBlack
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("grant_all_permissions_button")
                            ) {
                                Text(
                                    if (permissionSummary.allGranted) "পুনরায় যাচাই করুন"
                                    else "সব অনুমতি একসাথে দিন"
                                )
                            }
                            OutlinedButton(
                                onClick = onOpenAppSettings,
                                border = BorderStroke(1.dp, BorderViolet),
                                modifier = Modifier.testTag("open_app_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = "সিস্টেম সেটিংস",
                                    tint = NeonViolet,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Individual Permission Cards
            item {
                PermissionRowCard(
                    title = "মাইক্রোফোন (Microphone)",
                    description = "বাংলা ভয়েস কমান্ড ও ব্যাকগ্রাউন্ড ওয়েক-ওয়ার্ড শোনার জন্য।",
                    icon = Icons.Filled.Mic,
                    granted = permissionSummary.microphone,
                    onRequest = {
                        multiPermissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                    }
                )
            }

            item {
                PermissionRowCard(
                    title = "কন্টাক্টস (Contacts)",
                    description = "নাম ধরে কল করা এবং ইনকামিং কলারের নাম শনাক্ত করার জন্য।",
                    icon = Icons.Filled.Contacts,
                    granted = permissionSummary.contacts,
                    onRequest = {
                        multiPermissionLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS))
                    }
                )
            }

            item {
                PermissionRowCard(
                    title = "ফোন ও কল সহায়তা (Phone & Calls)",
                    description = "ডিরেক্ট কল করা ও ইনকামিং কল রিসিভ/কাটার সহায়তার জন্য।",
                    icon = Icons.Filled.Phone,
                    granted = permissionSummary.phoneAndCalls,
                    onRequest = {
                        val perms = buildList {
                            add(Manifest.permission.CALL_PHONE)
                            add(Manifest.permission.READ_PHONE_STATE)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                add(Manifest.permission.ANSWER_PHONE_CALLS)
                            }
                        }.toTypedArray()
                        multiPermissionLauncher.launch(perms)
                    }
                )
            }

            item {
                PermissionRowCard(
                    title = "ক্যামেরা ও ফ্ল্যাশ (Camera & Torch)",
                    description = "ফ্ল্যাশলাইট ও ক্যামেরা ভয়েস কন্ট্রোলের জন্য।",
                    icon = Icons.Filled.CameraAlt,
                    granted = permissionSummary.camera,
                    onRequest = {
                        multiPermissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                    }
                )
            }

            item {
                PermissionRowCard(
                    title = "নোটিফিকেশন (Notifications)",
                    description = "ব্যাকগ্রাউন্ড ভয়েস সার্ভিস স্ট্যাটাস সক্রিয় রাখার জন্য।",
                    icon = Icons.Filled.Notifications,
                    granted = permissionSummary.notifications,
                    onRequest = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            multiPermissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                        } else {
                            onPermissionsUpdated()
                        }
                    }
                )
            }

            // Male Bengali Voice Settings
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = CardObsidian,
                    border = BorderStroke(1.dp, BorderViolet)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = null,
                                tint = CyberCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "পুরুষ বাংলা ভয়েস সেটিংস",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PlasmaGlow
                                )
                                Text(
                                    text = activeVoiceLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonViolet
                                )
                            }
                        }

                        if (isBengaliVoiceMissing) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                onClick = onOpenTtsSettings,
                                shape = MaterialTheme.shapes.medium,
                                color = WarningAmber.copy(alpha = 0.14f),
                                border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "ডিভাইসে বাংলা TTS ডেটা ইনস্টল নেই। এখান থেকে Google TTS সেটিংস খুলে বাংলা ডাউনলোড করুন →",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PlasmaGlow,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "বাংলা রিকগনিশন ডায়ালেক্ট",
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("bn-BD" to "বাংলাদেশ (bn-BD)", "bn-IN" to "ভারত (bn-IN)").forEach { (tag, label) ->
                                FilterChip(
                                    selected = settings.speechLocale == tag,
                                    onClick = { onSelectDialect(tag) },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = DeepPurple,
                                        selectedLabelColor = PlasmaGlow
                                    )
                                )
                            }
                        }

                        if (availableVoices.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "ইনস্টল করা বাংলা ভয়েস প্রোফাইল (${availableVoices.size})",
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                availableVoices.take(4).forEachIndexed { index, voice ->
                                    val selected = settings.preferredVoiceName == voice.name ||
                                        (settings.preferredVoiceName.isBlank() && index == 0)
                                    Surface(
                                        onClick = { onSelectVoice(voice.name) },
                                        shape = MaterialTheme.shapes.small,
                                        color = if (selected) DeepPurple.copy(alpha = 0.5f) else ElevatedObsidian,
                                        border = BorderStroke(
                                            1.dp,
                                            if (selected) CyberCyan else BorderViolet
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${voice.localeTag} • ${if (voice.isNetworkRequired) "HD Network" else "Offline"}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = if (selected) "সক্রিয়" else "বেছে নিন",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = if (selected) CyberCyan else TextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "পুরুষ কণ্ঠের গভীরতা (Pitch): ${"%.2f".format(settings.malePitch)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Slider(
                            value = settings.malePitch,
                            onValueChange = onPitchChange,
                            valueRange = 0.65f..1.10f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = ElectricPurple
                            )
                        )

                        Text(
                            text = "কথার গতি (Speed): ${"%.2f".format(settings.speechRate)}x",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Slider(
                            value = settings.speechRate,
                            onValueChange = onRateChange,
                            valueRange = 0.75f..1.30f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = ElectricPurple
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onTestMaleVoice,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = VoidBlack
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("test_male_voice_button")
                            ) {
                                Text("পুরুষ বাংলা ভয়েস টেস্ট")
                            }
                            OutlinedButton(
                                onClick = onOpenTtsSettings,
                                border = BorderStroke(1.dp, BorderViolet)
                            ) {
                                Text("TTS সেটিংস", color = NeonViolet)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRowCard(
    title: String,
    description: String,
    icon: ImageVector,
    granted: Boolean,
    onRequest: () -> Unit
) {
    Surface(
        onClick = { if (!granted) onRequest() },
        shape = MaterialTheme.shapes.medium,
        color = ElevatedObsidian,
        border = BorderStroke(
            1.dp,
            if (granted) SuccessMint.copy(alpha = 0.5f) else BorderViolet
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (granted) SuccessMint else NeonViolet,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                contentDescription = if (granted) "অনুমতি আছে" else "অনুমতি দিন",
                tint = if (granted) SuccessMint else ElectricPurple,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
