package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VoidBlack = Color(0xFF05050A)
val ObsidianSurface = Color(0xFF0B0914)
val ElevatedObsidian = Color(0xFF141026)
val CardObsidian = Color(0xFF1A1433)
val BorderViolet = Color(0xFF312257)

val ElectricPurple = Color(0xFFA855F7)
val NeonViolet = Color(0xFFC084FC)
val DeepPurple = Color(0xFF6B21A8)
val RoyalViolet = Color(0xFF7E22CE)
val PlasmaGlow = Color(0xFFF3E8FF)

val CyberCyan = Color(0xFF22D3EE)
val PulseMagenta = Color(0xFFE879F9)
val SuccessMint = Color(0xFF34D399)
val WarningAmber = Color(0xFFFBBF24)
val AlertCoral = Color(0xFFFB7185)

val TextPrimary = Color(0xFFF8F7FF)
val TextSecondary = Color(0xFFB8B0D0)
val TextMuted = Color(0xFF7C7399)
