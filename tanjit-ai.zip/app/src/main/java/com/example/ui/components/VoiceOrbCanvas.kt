package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.OrbState
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepPurple
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.PlasmaGlow
import com.example.ui.theme.PulseMagenta
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidBlack
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VoiceOrbControl(
    orbState: OrbState,
    rmsLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    orbSize: Dp = 188.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_transition")

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (orbState) {
                    OrbState.THINKING -> 1600
                    OrbState.LISTENING -> 3800
                    OrbState.SPEAKING -> 2800
                    else -> 9000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_rotation"
    )

    val breathing by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_breathing"
    )

    val animatedRms by animateFloatAsState(
        targetValue = rmsLevel.coerceIn(0f, 1f),
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 350f),
        label = "rms_spring"
    )

    val primaryGlow by animateColorAsState(
        targetValue = when (orbState) {
            OrbState.IDLE -> ElectricPurple
            OrbState.LISTENING -> CyberCyan
            OrbState.THINKING -> PulseMagenta
            OrbState.SPEAKING -> NeonViolet
            OrbState.ERROR -> AlertCoral
        },
        animationSpec = tween(250),
        label = "primary_glow"
    )

    val secondaryGlow by animateColorAsState(
        targetValue = when (orbState) {
            OrbState.IDLE -> DeepPurple
            OrbState.LISTENING -> ElectricPurple
            OrbState.THINKING -> CyberCyan
            OrbState.SPEAKING -> PulseMagenta
            OrbState.ERROR -> DeepPurple
        },
        animationSpec = tween(250),
        label = "secondary_glow"
    )

    val statusTextBn = when (orbState) {
        OrbState.IDLE -> "ট্যাপ করে বাংলায় বলুন"
        OrbState.LISTENING -> "শুনছি… এখন কথা বলুন"
        OrbState.THINKING -> "TANJIT AI প্রসেস করছে…"
        OrbState.SPEAKING -> "বাংলা পুরুষ ভয়েসে উত্তর দিচ্ছি…"
        OrbState.ERROR -> "পুনরায় চেষ্টা করতে ট্যাপ করুন"
    }

    val interactionSource = remember { MutableInteractionSource() }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(orbSize)
                .clip(CircleShape)
                .testTag("mic_orb_button")
                .semantics {
                    contentDescription = "TANJIT AI Voice Orb: $statusTextBn"
                }
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(bounded = true, color = primaryGlow),
                    role = Role.Button,
                    onClick = onClick
                )
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.minDimension * 0.31f
                val pulseBoost = when (orbState) {
                    OrbState.LISTENING -> baseRadius * (0.28f * animatedRms + 0.08f * breathing)
                    OrbState.SPEAKING -> baseRadius * (0.18f * breathing)
                    OrbState.THINKING -> baseRadius * 0.12f
                    else -> baseRadius * 0.05f * breathing
                }

                // Ambient halo
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryGlow.copy(alpha = 0.38f),
                            secondaryGlow.copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = size.minDimension * 0.50f
                    ),
                    radius = size.minDimension * 0.50f,
                    center = center
                )

                // Outer cybernetic orbit ring
                rotate(degrees = rotationAngle, pivot = center) {
                    val ringRadius = baseRadius + pulseBoost + 18f
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                primaryGlow.copy(alpha = 0.9f),
                                Color.Transparent,
                                secondaryGlow.copy(alpha = 0.7f),
                                Color.Transparent
                            ),
                            center = center
                        ),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = Offset(center.x - ringRadius, center.y - ringRadius),
                        size = androidx.compose.ui.geometry.Size(ringRadius * 2f, ringRadius * 2f),
                        style = Stroke(width = 4.5f, cap = StrokeCap.Round)
                    )

                    // Orbiting telemetry nodes
                    for (i in 0 until 4) {
                        val rad = Math.toRadians((i * 90.0))
                        val nodeOffset = Offset(
                            x = center.x + (ringRadius * cos(rad)).toFloat(),
                            y = center.y + (ringRadius * sin(rad)).toFloat()
                        )
                        drawCircle(
                            color = if (i % 2 == 0) PlasmaGlow else primaryGlow,
                            radius = if (orbState == OrbState.LISTENING) 5.5f else 4f,
                            center = nodeOffset
                        )
                    }
                }

                // Counter-rotating inner ring
                rotate(degrees = -rotationAngle * 1.4f, pivot = center) {
                    val innerRadius = baseRadius + pulseBoost * 0.4f + 6f
                    drawArc(
                        color = primaryGlow.copy(alpha = 0.45f),
                        startAngle = 20f,
                        sweepAngle = 140f,
                        useCenter = false,
                        topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
                        size = androidx.compose.ui.geometry.Size(innerRadius * 2f, innerRadius * 2f),
                        style = Stroke(width = 3f, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = secondaryGlow.copy(alpha = 0.55f),
                        startAngle = 200f,
                        sweepAngle = 130f,
                        useCenter = false,
                        topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
                        size = androidx.compose.ui.geometry.Size(innerRadius * 2f, innerRadius * 2f),
                        style = Stroke(width = 3f, cap = StrokeCap.Round)
                    )
                }

                // Obsidian core sphere with neon rim
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryGlow.copy(alpha = 0.35f),
                            DeepPurple.copy(alpha = 0.72f),
                            VoidBlack.copy(alpha = 0.96f)
                        ),
                        center = center,
                        radius = baseRadius
                    ),
                    radius = baseRadius,
                    center = center
                )
                drawCircle(
                    color = primaryGlow.copy(alpha = 0.85f),
                    radius = baseRadius,
                    center = center,
                    style = Stroke(width = 2.5f)
                )
            }

            Icon(
                imageVector = when (orbState) {
                    OrbState.IDLE -> Icons.Filled.Mic
                    OrbState.LISTENING -> Icons.Filled.GraphicEq
                    OrbState.THINKING -> Icons.Filled.AutoAwesome
                    OrbState.SPEAKING -> Icons.AutoMirrored.Filled.VolumeUp
                    OrbState.ERROR -> Icons.Filled.WarningAmber
                },
                contentDescription = null,
                tint = PlasmaGlow,
                modifier = Modifier.size(38.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = statusTextBn,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = if (orbState == OrbState.ERROR) AlertCoral else TextSecondary
        )
    }
}
