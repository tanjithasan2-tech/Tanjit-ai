package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AssistantSettings
import com.example.data.CallAssistEvent
import com.example.data.IncomingCallState
import com.example.data.PermissionSummary
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.BorderViolet
import com.example.ui.theme.CardObsidian
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElevatedObsidian
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.PlasmaGlow
import com.example.ui.theme.SuccessMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidBlack
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ServiceAndCallsScreen(
    isBackgroundRunning: Boolean,
    settings: AssistantSettings,
    incomingCallState: IncomingCallState,
    callEvents: List<CallAssistEvent>,
    permissionSummary: PermissionSummary,
    onToggleBackgroundService: (Boolean) -> Unit,
    onToggleWakeWordOnly: (Boolean) -> Unit,
    onToggleIncomingAnnounce: (Boolean) -> Unit,
    onToggleIncomingVoiceControl: (Boolean) -> Unit,
    onAnswerCall: () -> Unit,
    onDeclineCall: () -> Unit,
    onNavigateToSetup: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(VoidBlack, ObsidianSurface, VoidBlack))),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "BACKGROUND & CALLS",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PlasmaGlow
                    )
                    Text(
                        text = "ব্যাকগ্রাউন্ড ভয়েস সার্ভিস ও ইনকামিং কল সহায়তা",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            // Live Incoming Call Banner (shown only when a real call is ringing)
            item {
                AnimatedVisibility(visible = incomingCallState.isRinging) {
                    Surface(
                        shape = MaterialTheme.shapes.large,
                        color = ElectricPurple.copy(alpha = 0.22f),
                        border = BorderStroke(1.5.dp, CyberCyan),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.PhoneInTalk,
                                    contentDescription = null,
                                    tint = CyberCyan
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ইনকামিং কল আসছে!",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = PlasmaGlow
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = incomingCallState.callerName
                                    ?: incomingCallState.phoneNumber
                                    ?: "অজানা নম্বর",
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onAnswerCall,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SuccessMint,
                                        contentColor = VoidBlack
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Filled.Call, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("রিসিভ করুন")
                                }
                                Button(
                                    onClick = onDeclineCall,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AlertCoral,
                                        contentColor = VoidBlack
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Filled.CallEnd, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("কেটে দিন")
                                }
                            }
                        }
                    }
                }
            }

            // Background Voice Service Control Card
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = CardObsidian,
                    border = BorderStroke(
                        1.dp,
                        if (isBackgroundRunning) CyberCyan.copy(alpha = 0.7f) else BorderViolet
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PowerSettingsNew,
                                    contentDescription = null,
                                    tint = if (isBackgroundRunning) CyberCyan else NeonViolet,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "ব্যাকগ্রাউন্ড ভয়েস সার্ভিস",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = PlasmaGlow
                                    )
                                    Text(
                                        text = if (isBackgroundRunning)
                                            "সক্রিয় আছে • 'তানজিত' বললে সাড়া দেবে"
                                        else
                                            "অ্যাপ মিনিমাইজ থাকলেও ভয়েস শুনবে",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isBackgroundRunning) CyberCyan else TextSecondary
                                    )
                                }
                            }

                            Switch(
                                checked = isBackgroundRunning,
                                onCheckedChange = { enable ->
                                    if (enable && !permissionSummary.microphone) {
                                        onNavigateToSetup()
                                    } else {
                                        onToggleBackgroundService(enable)
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = VoidBlack,
                                    checkedTrackColor = CyberCyan,
                                    uncheckedThumbColor = TextSecondary,
                                    uncheckedTrackColor = ElevatedObsidian
                                ),
                                modifier = Modifier.testTag("background_service_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Hearing,
                                    contentDescription = null,
                                    tint = ElectricPurple,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "ওয়েক-ওয়ার্ড মোড ('তানজিত')",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "চালু থাকলে শুধু 'তানজিত' বলার পর কমান্ড নেবে",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Switch(
                                checked = settings.wakeWordOnlyInBackground,
                                onCheckedChange = onToggleWakeWordOnly,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = VoidBlack,
                                    checkedTrackColor = ElectricPurple
                                ),
                                modifier = Modifier.testTag("wake_word_switch")
                            )
                        }
                    }
                }
            }

            // Incoming Call Assistant Settings
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = CardObsidian,
                    border = BorderStroke(1.dp, BorderViolet)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.RecordVoiceOver,
                                contentDescription = null,
                                tint = NeonViolet
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "ইনকামিং কল অ্যাসিস্ট্যান্ট",
                                style = MaterialTheme.typography.titleMedium,
                                color = PlasmaGlow
                            )
                        }

                        if (!permissionSummary.phoneAndCalls) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                onClick = onNavigateToSetup,
                                shape = MaterialTheme.shapes.medium,
                                color = ElevatedObsidian,
                                border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "ইনকামিং কল শনাক্ত ও উত্তর দিতে ফোন ও কল সহায়তা অনুমতি দিন →",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CyberCyan,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "বাংলায় কলারের নাম ঘোষণা",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "ফোন এলে পুরুষ বাংলা ভয়েসে কে কল করছে তা বলবে",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                            Switch(
                                checked = settings.incomingCallAnnounce,
                                onCheckedChange = onToggleIncomingAnnounce,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = VoidBlack,
                                    checkedTrackColor = ElectricPurple
                                ),
                                modifier = Modifier.testTag("incoming_announce_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "ভয়েস দিয়ে কল রিসিভ / রিজেক্ট",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "রিং হলে বলুন 'রিসিভ করো' অথবা 'কেটে দাও'",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                            Switch(
                                checked = settings.incomingCallVoiceControl,
                                onCheckedChange = onToggleIncomingVoiceControl,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = VoidBlack,
                                    checkedTrackColor = ElectricPurple
                                ),
                                modifier = Modifier.testTag("incoming_voice_control_switch")
                            )
                        }
                    }
                }
            }

            // Recent Incoming Call Assist Log
            item {
                Text(
                    text = "ইনকামিং কল হিস্ট্রি",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonViolet
                )
            }

            if (callEvents.isEmpty()) {
                item {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = ElevatedObsidian,
                        border = BorderStroke(1.dp, BorderViolet)
                    ) {
                        Text(
                            text = "এখনো কোনো ইনকামিং কল শনাক্ত হয়নি। সার্ভিস চালু থাকলে নতুন কল এলে এখানে দেখাবে।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            } else {
                items(callEvents, key = { it.id }) { event ->
                    val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault())
                        .format(Date(event.timestampMillis))
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = ElevatedObsidian,
                        border = BorderStroke(1.dp, BorderViolet)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = event.callerLabel,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = event.statusLabel,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CyberCyan
                                )
                            }
                            Text(
                                text = timeStr,
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
