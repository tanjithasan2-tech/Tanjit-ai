package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CameraFront
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ContactMatch
import com.example.data.PermissionSummary
import com.example.ui.theme.BorderViolet
import com.example.ui.theme.CardObsidian
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElevatedObsidian
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.PlasmaGlow
import com.example.ui.theme.PulseMagenta
import com.example.ui.theme.SuccessMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidBlack

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CommandHubScreen(
    isTorchOn: Boolean,
    hasFlashlight: Boolean,
    contacts: List<ContactMatch>,
    permissionSummary: PermissionSummary,
    onOpenYouTube: (String?) -> Unit,
    onOpenFacebook: () -> Unit,
    onOpenWebsite: (String) -> Unit,
    onToggleFlashlight: () -> Unit,
    onOpenCamera: (Boolean) -> Unit,
    onCallContact: (ContactMatch) -> Unit,
    onNavigateToSetup: () -> Unit,
    modifier: Modifier = Modifier
) {
    var websiteInput by rememberSaveable { mutableStateOf("") }
    var youtubeSearch by rememberSaveable { mutableStateOf("") }
    var contactFilter by rememberSaveable { mutableStateOf("") }

    val filteredContacts = remember(contacts, contactFilter) {
        if (contactFilter.isBlank()) contacts.take(15)
        else contacts.filter {
            it.name.contains(contactFilter, ignoreCase = true) ||
                it.phoneNumber.contains(contactFilter)
        }.take(20)
    }

    val popularWebsites = listOf(
        "google.com" to "Google",
        "prothomalo.com" to "প্রথম আলো",
        "bn.wikipedia.org" to "উইকিপিডিয়া",
        "bbc.com/bengali" to "বিবিসি বাংলা",
        "github.com" to "GitHub",
        "mail.google.com" to "Gmail"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(VoidBlack, ObsidianSurface, VoidBlack))),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "COMMAND HUB",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PlasmaGlow
                    )
                    Text(
                        text = "অ্যাপ লঞ্চ, ওয়েবসাইট, হার্ডওয়্যার ও দ্রুত কল কন্ট্রোল",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            // YouTube & Facebook Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LaunchTileCard(
                        title = "YouTube",
                        subtitle = "ভয়েস: 'ইউটিউব খোলো'",
                        icon = Icons.Filled.PlayCircleFilled,
                        accent = PulseMagenta,
                        onClick = { onOpenYouTube(null) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_youtube_card")
                    )
                    LaunchTileCard(
                        title = "Facebook",
                        subtitle = "ভয়েস: 'ফেসবুক খোলো'",
                        icon = Icons.Filled.Public,
                        accent = CyberCyan,
                        onClick = onOpenFacebook,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_facebook_card")
                    )
                }
            }

            // YouTube Search Box
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = CardObsidian,
                    border = BorderStroke(1.dp, BorderViolet)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "ইউটিউব দ্রুত সার্চ",
                            style = MaterialTheme.typography.titleMedium,
                            color = PlasmaGlow
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = youtubeSearch,
                                onValueChange = { youtubeSearch = it },
                                placeholder = { Text("যেমন: বাংলা নাটক বা গজল", color = TextMuted) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(
                                    onSearch = {
                                        if (youtubeSearch.isNotBlank()) {
                                            onOpenYouTube(youtubeSearch)
                                            youtubeSearch = ""
                                        }
                                    }
                                ),
                                colors = darkFieldColors(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    onOpenYouTube(youtubeSearch.ifBlank { null })
                                    youtubeSearch = ""
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricPurple,
                                    contentColor = VoidBlack
                                ),
                                modifier = Modifier.height(52.dp)
                            ) {
                                Text("খুঁজুন")
                            }
                        }
                    }
                }
            }

            // Website Launcher
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = CardObsidian,
                    border = BorderStroke(1.dp, BorderViolet)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Language,
                                contentDescription = null,
                                tint = CyberCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "যেকোনো ওয়েবসাইট খুলুন",
                                style = MaterialTheme.typography.titleMedium,
                                color = PlasmaGlow
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = websiteInput,
                                onValueChange = { websiteInput = it },
                                placeholder = { Text("example.com লিখুন", color = TextMuted) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                keyboardActions = KeyboardActions(
                                    onGo = {
                                        if (websiteInput.isNotBlank()) {
                                            onOpenWebsite(websiteInput)
                                            websiteInput = ""
                                        }
                                    }
                                ),
                                colors = darkFieldColors(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("website_url_input")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (websiteInput.isNotBlank()) {
                                        onOpenWebsite(websiteInput)
                                        websiteInput = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = VoidBlack
                                ),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("open_website_button")
                            ) {
                                Text("ভিজিট")
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            popularWebsites.forEach { (url, label) ->
                                AssistChip(
                                    onClick = { onOpenWebsite(url) },
                                    label = { Text(label, color = PlasmaGlow) },
                                    colors = AssistChipDefaults.assistChipColors(
                                        containerColor = ElevatedObsidian
                                    ),
                                    border = BorderStroke(1.dp, BorderViolet)
                                )
                            }
                        }
                    }
                }
            }

            // Hardware Controls: Flashlight + Camera + Selfie
            item {
                Text(
                    text = "হার্ডওয়্যার কন্ট্রোল",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonViolet
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LaunchTileCard(
                        title = if (isTorchOn) "ফ্ল্যাশ ON" else "ফ্ল্যাশ OFF",
                        subtitle = if (hasFlashlight) "ট্যাপ করে বদলান" else "ফ্ল্যাশ অনুপলব্ধ",
                        icon = if (isTorchOn) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff,
                        accent = if (isTorchOn) SuccessMint else ElectricPurple,
                        onClick = onToggleFlashlight,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("flashlight_toggle_button")
                    )
                    LaunchTileCard(
                        title = "ক্যামেরা",
                        subtitle = "ছবি বা ভিডিও",
                        icon = Icons.Filled.CameraAlt,
                        accent = NeonViolet,
                        onClick = { onOpenCamera(false) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("camera_launch_button")
                    )
                    LaunchTileCard(
                        title = "সেলফি",
                        subtitle = "ফ্রন্ট ক্যামেরা",
                        icon = Icons.Filled.CameraFront,
                        accent = PulseMagenta,
                        onClick = { onOpenCamera(true) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("selfie_camera_button")
                    )
                }
            }

            // Contacts Quick Dial
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "সেভ করা কন্টাক্টস (কল করুন)",
                        style = MaterialTheme.typography.titleMedium,
                        color = NeonViolet
                    )
                    Text(
                        text = "${contacts.size} টি কন্টাক্ট",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                }
            }

            if (!permissionSummary.contacts) {
                item {
                    Surface(
                        onClick = onNavigateToSetup,
                        shape = MaterialTheme.shapes.large,
                        color = CardObsidian,
                        border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Contacts,
                                contentDescription = null,
                                tint = ElectricPurple,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "কন্টাক্টস অনুমতি প্রয়োজন",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PlasmaGlow
                                )
                                Text(
                                    text = "ভয়েস দিয়ে সেভ করা নম্বরে কল করতে কন্টাক্টস অ্যাক্সেস দিন।",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            } else {
                item {
                    OutlinedTextField(
                        value = contactFilter,
                        onValueChange = { contactFilter = it },
                        placeholder = { Text("নাম বা নম্বর দিয়ে খুঁজুন…", color = TextMuted) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                tint = NeonViolet
                            )
                        },
                        singleLine = true,
                        colors = darkFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("contact_search_input")
                    )
                }

                if (filteredContacts.isEmpty()) {
                    item {
                        Text(
                            text = "কোনো কন্টাক্ট পাওয়া যায়নি।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                } else {
                    items(filteredContacts, key = { "${it.id}_${it.phoneNumber}" }) { contact ->
                        Surface(
                            onClick = { onCallContact(contact) },
                            shape = MaterialTheme.shapes.medium,
                            color = ElevatedObsidian,
                            border = BorderStroke(1.dp, BorderViolet),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = contact.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = contact.phoneNumber,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TextSecondary
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SuccessMint.copy(alpha = 0.18f),
                                    border = BorderStroke(1.dp, SuccessMint.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Call,
                                            contentDescription = "কল করুন",
                                            tint = SuccessMint,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "কল",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = SuccessMint
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LaunchTileCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        color = CardObsidian,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accent,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = PlasmaGlow,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun darkFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = ElectricPurple,
    unfocusedBorderColor = BorderViolet,
    focusedContainerColor = ElevatedObsidian,
    unfocusedContainerColor = ElevatedObsidian,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = CyberCyan
)
