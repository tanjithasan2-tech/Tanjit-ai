package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AssistantSettings
import com.example.data.CallAssistEvent
import com.example.data.ContactMatch
import com.example.data.ConversationMessage
import com.example.data.IncomingCallState
import com.example.data.OrbState
import com.example.data.PermissionSummary
import com.example.data.VoiceProfile
import com.example.service.AssistantHub
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val hub = AssistantHub.getInstance(application)

    val orbState: StateFlow<OrbState> = hub.orbState
    val messages: StateFlow<List<ConversationMessage>> = hub.messages
    val settings: StateFlow<AssistantSettings> = hub.settings
    val isBackgroundServiceRunning: StateFlow<Boolean> = hub.isBackgroundServiceRunning
    val incomingCallState: StateFlow<IncomingCallState> = hub.incomingCallState
    val callAssistEvents: StateFlow<List<CallAssistEvent>> = hub.callAssistEvents
    val contacts: StateFlow<List<ContactMatch>> = hub.contacts
    val permissionSummary: StateFlow<PermissionSummary> = hub.permissionSummary
    val isTorchOn: StateFlow<Boolean> = hub.isTorchOn
    val hasFlashlight: StateFlow<Boolean> = hub.hasFlashlight
    val rmsLevel: StateFlow<Float> = hub.rmsLevel
    val partialSpeechText: StateFlow<String> = hub.partialSpeechText
    val isListening: StateFlow<Boolean> = hub.isSpeechListening
    val isSpeaking: StateFlow<Boolean> = hub.isSpeaking
    val isBengaliVoiceMissing: StateFlow<Boolean> = hub.isBengaliVoiceMissing
    val availableVoices: StateFlow<List<VoiceProfile>> = hub.availableVoices
    val activeVoiceLabel: StateFlow<String> = hub.activeVoiceLabel

    fun toggleListening() {
        if (isListening.value) {
            hub.stopForegroundListening()
        } else {
            hub.startForegroundListening()
        }
    }

    fun submitTextCommand(text: String) {
        viewModelScope.launch {
            hub.processUserCommand(text, speakReply = true)
        }
    }

    fun toggleFlashlight() {
        hub.toggleFlashlightAndAnnounce()
    }

    fun openCamera(frontFacing: Boolean = false) {
        hub.launchCameraAndAnnounce(frontFacing)
    }

    fun openYouTube(query: String? = null) {
        val cmd = if (query.isNullOrBlank()) "ইউটিউব খোলো" else "ইউটিউবে $query সার্চ করো"
        submitTextCommand(cmd)
    }

    fun openFacebook() {
        submitTextCommand("ফেসবুক খোলো")
    }

    fun openWebsite(url: String) {
        val trimmed = url.trim()
        if (trimmed.isNotEmpty()) {
            submitTextCommand("$trimmed খোলো")
        }
    }

    fun callContact(contact: ContactMatch) {
        hub.callContactDirect(contact)
    }

    fun answerIncomingCall() {
        submitTextCommand("কল রিসিভ করো")
    }

    fun declineIncomingCall() {
        submitTextCommand("কল কেটে দাও")
    }

    fun toggleBackgroundService(enable: Boolean): Boolean {
        return if (enable) {
            hub.startBackgroundService()
        } else {
            hub.stopBackgroundService()
            true
        }
    }

    fun refreshPermissions() {
        hub.refreshPermissions()
    }

    fun refreshContacts() {
        hub.refreshContacts()
    }

    fun setSpeechLocale(localeTag: String) {
        viewModelScope.launch { hub.settingsRepository.setSpeechLocale(localeTag) }
    }

    fun setMalePitch(pitch: Float) {
        viewModelScope.launch { hub.settingsRepository.setMalePitch(pitch) }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { hub.settingsRepository.setSpeechRate(rate) }
    }

    fun setPreferredVoice(voiceName: String) {
        viewModelScope.launch { hub.settingsRepository.setPreferredVoiceName(voiceName) }
    }

    fun setWakeWordOnly(wakeWordOnly: Boolean) {
        viewModelScope.launch { hub.settingsRepository.setWakeWordOnlyInBackground(wakeWordOnly) }
    }

    fun setIncomingCallAnnounce(enabled: Boolean) {
        viewModelScope.launch { hub.settingsRepository.setIncomingCallAnnounce(enabled) }
    }

    fun setIncomingCallVoiceControl(enabled: Boolean) {
        viewModelScope.launch { hub.settingsRepository.setIncomingCallVoiceControl(enabled) }
    }

    fun dismissPermissionBanner() {
        viewModelScope.launch { hub.settingsRepository.setPermissionOnboardingDismissed(true) }
    }

    fun testMaleVoice() {
        hub.testMaleBengaliVoice()
    }

    fun stopSpeaking() {
        hub.ttsManager.stopSpeaking()
    }

    fun clearConversation() {
        hub.clearConversation()
    }

    fun openTtsSettings() {
        hub.ttsManager.openTtsSettings()
    }

    fun openAppPermissionSettings() {
        val context = getApplication<Application>()
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
