package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TanjitDarkColorScheme = darkColorScheme(
    primary = ElectricPurple,
    onPrimary = VoidBlack,
    primaryContainer = DeepPurple,
    onPrimaryContainer = PlasmaGlow,
    secondary = CyberCyan,
    onSecondary = VoidBlack,
    secondaryContainer = ElevatedObsidian,
    onSecondaryContainer = TextPrimary,
    tertiary = PulseMagenta,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = CardObsidian,
    onSurfaceVariant = TextSecondary,
    outline = BorderViolet,
    outlineVariant = ColorTokens.SubtleOutline,
    error = AlertCoral,
    onError = VoidBlack
)

private object ColorTokens {
    val SubtleOutline = androidx.compose.ui.graphics.Color(0xFF231942)
}

val TanjitShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun TanjitAiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TanjitDarkColorScheme,
        typography = TanjitTypography,
        shapes = TanjitShapes,
        content = content
    )
}
