package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ConversationMessage
import com.example.data.MessageSender
import com.example.data.OrbState
import com.example.data.PermissionSummary
import com.example.ui.components.VoiceOrbControl
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.BorderViolet
import com.example.ui.theme.CardObsidian
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepPurple
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElevatedObsidian
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.PlasmaGlow
import com.example.ui.theme.SuccessMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidBlack
import com.example.ui.theme.WarningAmber

@Composable
fun AssistantScreen(
    orbState: OrbState,
    rmsLevel: Float,
    partialSpeechText: String,
    isSpeaking: Boolean,
    isTorchOn: Boolean,
    isBackgroundRunning: Boolean,
    permissionSummary: PermissionSummary,
    messages: List<ConversationMessage>,
    onOrbClick: () -> Unit,
    onStopSpeaking: () -> Unit,
    onToggleFlashlight: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onClearChat: () -> Unit,
    onNavigateToSetup: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val quickCommands = listOf(
        "ইউটিউব খোলো",
        "ফেসবুক খোলো",
        "ফ্ল্যাশলাইট জ্বালাও",
        "ক্যামেরা খোলো",
        "গুগল খোলো",
        "প্রথম আলো খোলো"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VoidBlack, ObsidianSurface, VoidBlack)
                )
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
        ) {
            // Futuristic Header & Neural Banner Backdrop
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VoidBlack)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tanjit_neural_banner_1794855662384),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .matchParentSize()
                        .alpha(0.28f)
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    VoidBlack.copy(alpha = 0.55f),
                                    VoidBlack.copy(alpha = 0.35f),
                                    VoidBlack
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top Telemetry Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "TANJIT AI",
                                style = MaterialTheme.typography.headlineMedium,
                                color = PlasmaGlow
                            )
                            Text(
                                text = if (isBackgroundRunning) "NEURAL CORE • ব্যাকগ্রাউন্ড সক্রিয়"
                                else "BENGALI VOICE ASSISTANT",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isBackgroundRunning) CyberCyan else NeonViolet
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                onClick = onToggleFlashlight,
                                shape = CircleShape,
                                color = if (isTorchOn) ElectricPurple.copy(alpha = 0.25f) else ElevatedObsidian,
                                border = BorderStroke(1.dp, if (isTorchOn) ElectricPurple else BorderViolet),
                                modifier = Modifier.testTag("header_flashlight_button")
                            ) {
                                Icon(
                                    imageVector = if (isTorchOn) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff,
                                    contentDescription = "ফ্ল্যাশলাইট টগল করুন",
                                    tint = if (isTorchOn) CyberCyan else TextSecondary,
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .size(20.dp)
                                )
                            }

                            IconButton(
                                onClick = onClearChat,
                                modifier = Modifier.testTag("clear_chat_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "চ্যাট পরিষ্কার করুন",
                                    tint = TextSecondary
                                )
                            }
                        }
                    }

                    // Permission warning banner if microphone is not granted
                    AnimatedVisibility(visible = !permissionSummary.microphone) {
                        Surface(
                            onClick = onNavigateToSetup,
                            shape = MaterialTheme.shapes.medium,
                            color = WarningAmber.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                                .testTag("mic_permission_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Security,
                                    contentDescription = null,
                                    tint = WarningAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "বাংলা ভয়েস কমান্ডের জন্য মাইক্রোফোন অনুমতি দিন →",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PlasmaGlow,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    VoiceOrbControl(
                        orbState = orbState,
                        rmsLevel = rmsLevel,
                        onClick = onOrbClick,
                        orbSize = 172.dp
                    )

                    // Live partial Bengali transcription or Stop Speaking pill
                    AnimatedVisibility(visible = partialSpeechText.isNotBlank()) {
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = CardObsidian.copy(alpha = 0.9f),
                            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.GraphicEq,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = partialSpeechText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    AnimatedVisibility(visible = isSpeaking) {
                        AssistChip(
                            onClick = onStopSpeaking,
                            label = { Text("ভয়েস থামান", color = PlasmaGlow) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.StopCircle,
                                    contentDescription = null,
                                    tint = AlertCoral,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = ElevatedObsidian
                            ),
                            border = BorderStroke(1.dp, AlertCoral.copy(alpha = 0.55f)),
                            modifier = Modifier
                                .padding(top = 6.dp)
                                .testTag("stop_speaking_chip")
                        )
                    }
                }
            }

            // Quick Bengali Command Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickCommands.forEach { cmd ->
                    AssistChip(
                        onClick = { onSubmitCommand(cmd) },
                        label = {
                            Text(
                                text = cmd,
                                style = MaterialTheme.typography.bodyMedium,
                                color = PlasmaGlow
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = CardObsidian
                        ),
                        border = BorderStroke(1.dp, BorderViolet)
                    )
                }
            }

            // Conversation History
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ConversationBubble(message = msg)
                }
            }

            // Bottom Command Text Input Bar
            Surface(
                color = ObsidianSurface,
                border = BorderStroke(1.dp, BorderViolet.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = "বাংলা বা ইংরেজিতে কমান্ড লিখুন…",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (inputText.isNotBlank()) {
                                    onSubmitCommand(inputText)
                                    inputText = ""
                                }
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricPurple,
                            unfocusedBorderColor = BorderViolet,
                            focusedContainerColor = ElevatedObsidian,
                            unfocusedContainerColor = ElevatedObsidian,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = CyberCyan
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("command_text_input")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    FilledIconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                onSubmitCommand(inputText)
                                inputText = ""
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = ElectricPurple,
                            contentColor = VoidBlack
                        ),
                        modifier = Modifier
                            .size(50.dp)
                            .testTag("send_command_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "কমান্ড পাঠান"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationBubble(message: ConversationMessage) {
    val isUser = message.sender == MessageSender.USER
    val isSystem = message.sender == MessageSender.SYSTEM

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 18.dp
            ),
            color = when {
                message.isError -> AlertCoral.copy(alpha = 0.14f)
                isUser -> DeepPurple.copy(alpha = 0.55f)
                isSystem -> ElevatedObsidian
                else -> CardObsidian
            },
            border = BorderStroke(
                width = 1.dp,
                color = when {
                    message.isError -> AlertCoral.copy(alpha = 0.6f)
                    isUser -> ElectricPurple.copy(alpha = 0.7f)
                    else -> BorderViolet
                }
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = when (message.sender) {
                            MessageSender.USER -> "আপনি"
                            MessageSender.ASSISTANT -> "TANJIT AI"
                            MessageSender.SYSTEM -> "সিস্টেম"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = when {
                            message.isError -> AlertCoral
                            isUser -> CyberCyan
                            else -> NeonViolet
                        }
                    )

                    if (!message.actionBadge.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (message.isError) AlertCoral.copy(alpha = 0.2f)
                                    else SuccessMint.copy(alpha = 0.16f)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = message.actionBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (message.isError) AlertCoral else SuccessMint
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary
                )
            }
        }
    }
}
