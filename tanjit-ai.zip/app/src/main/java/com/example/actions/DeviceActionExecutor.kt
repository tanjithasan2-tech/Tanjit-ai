package com.example.actions

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.CommandExecutionResult
import com.example.data.ContactMatch
import java.net.URLEncoder
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

private const val TAG = "DeviceActionExecutor"

class DeviceActionExecutor(private val context: Context) {

    private val cameraManager: CameraManager? =
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private val _hasFlashlight = MutableStateFlow(false)
    val hasFlashlight: StateFlow<Boolean> = _hasFlashlight.asStateFlow()

    private var torchCameraId: String? = null

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchCameraId) {
                _isTorchOn.value = enabled
            }
        }

        override fun onTorchModeUnavailable(cameraId: String) {
            if (cameraId == torchCameraId) {
                _isTorchOn.value = false
            }
        }
    }

    init {
        discoverTorchCamera()
    }

    private fun discoverTorchCamera() {
        val manager = cameraManager ?: return
        try {
            val backFlashId = manager.cameraIdList.firstOrNull { id ->
                val chars = manager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            torchCameraId = backFlashId
            _hasFlashlight.value = backFlashId != null
            if (backFlashId != null) {
                manager.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error discovering flashlight camera", e)
            _hasFlashlight.value = false
        }
    }

    fun openYouTube(searchQuery: String? = null): CommandExecutionResult {
        return try {
            val cleanQuery = searchQuery?.trim().orEmpty()
            if (cleanQuery.isNotEmpty()) {
                val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                val searchIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=$encoded")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val ytPackageIntent = Intent(searchIntent).setPackage("com.google.android.youtube")
                if (ytPackageIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(ytPackageIntent)
                } else {
                    context.startActivity(searchIntent)
                }
                CommandExecutionResult(
                    spokenReplyBn = "ইউটিউবে '$cleanQuery' খুঁজে দিচ্ছি।",
                    actionBadge = "YouTube Search"
                )
            } else {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    ?.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                if (launchIntent != null) {
                    context.startActivity(launchIntent)
                } else {
                    val webIntent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://m.youtube.com")
                    ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    context.startActivity(webIntent)
                }
                CommandExecutionResult(
                    spokenReplyBn = "ইউটিউব খুলে দিচ্ছি।",
                    actionBadge = "YouTube"
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed opening YouTube", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, ইউটিউব খোলা সম্ভব হয়নি।",
                isError = true
            )
        }
    }

    fun openFacebook(): CommandExecutionResult {
        return try {
            val fbIntent = context.packageManager.getLaunchIntentForPackage("com.facebook.katana")
                ?: context.packageManager.getLaunchIntentForPackage("com.facebook.lite")
            if (fbIntent != null) {
                fbIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(fbIntent)
            } else {
                val webIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.facebook.com")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(webIntent)
            }
            CommandExecutionResult(
                spokenReplyBn = "ফেসবুক খুলে দিচ্ছি।",
                actionBadge = "Facebook"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed opening Facebook", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, ফেসবুক খোলা সম্ভব হয়নি।",
                isError = true
            )
        }
    }

    fun openWebsite(rawUrl: String, displayLabel: String = rawUrl): CommandExecutionResult {
        val normalized = normalizeUrl(rawUrl)
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CommandExecutionResult(
                spokenReplyBn = "$displayLabel ওয়েবসাইট খুলে দিচ্ছি।",
                actionBadge = Uri.parse(normalized).host ?: "Website"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed opening website: $normalized", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, $displayLabel ওয়েবসাইটটি খোলা যায়নি।",
                isError = true
            )
        }
    }

    fun setFlashlight(enabled: Boolean): CommandExecutionResult {
        val manager = cameraManager
        val id = torchCameraId
        if (manager == null || id == null) {
            return CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, এই ডিভাইসে ফ্ল্যাশলাইট পাওয়া যায়নি।",
                isError = true
            )
        }
        return try {
            manager.setTorchMode(id, enabled)
            _isTorchOn.value = enabled
            CommandExecutionResult(
                spokenReplyBn = if (enabled) "ফ্ল্যাশলাইট জ্বালিয়ে দিয়েছি।" else "ফ্ল্যাশলাইট বন্ধ করে দিয়েছি।",
                actionBadge = if (enabled) "Flashlight ON" else "Flashlight OFF"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed toggling flashlight", e)
            CommandExecutionResult(
                spokenReplyBn = "ফ্ল্যাশলাইট নিয়ন্ত্রণ করা যায়নি। ক্যামেরা অন্য অ্যাপে ব্যবহার হতে পারে।",
                isError = true
            )
        }
    }

    fun toggleFlashlight(): CommandExecutionResult {
        return setFlashlight(!_isTorchOn.value)
    }

    fun openCamera(frontFacing: Boolean = false): CommandExecutionResult {
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (frontFacing) {
                    putExtra("android.intent.extras.CAMERA_FACING", 1)
                    putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                    putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
                }
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                val fallback = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            }
            CommandExecutionResult(
                spokenReplyBn = if (frontFacing) "সেলফি ক্যামেরা খুলে দিচ্ছি।" else "ক্যামেরা খুলে দিচ্ছি।",
                actionBadge = if (frontFacing) "Selfie Camera" else "Camera"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed opening camera", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, ক্যামেরা খোলা সম্ভব হয়নি।",
                isError = true
            )
        }
    }

    suspend fun loadSavedContacts(limit: Int = 200): List<ContactMatch> = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return@withContext emptyList()
        }
        val list = mutableListOf<ContactMatch>()
        val seenKeys = hashSetOf<String>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && list.size < limit) {
                    val id = cursor.getString(idIdx).orEmpty()
                    val name = cursor.getString(nameIdx)?.trim().orEmpty()
                    val number = cursor.getString(numIdx)?.trim().orEmpty()
                    if (name.isNotEmpty() && number.isNotEmpty()) {
                        val dedupKey = "${name.lowercase(Locale.ROOT)}_${number.filter { it.isDigit() }}"
                        if (seenKeys.add(dedupKey)) {
                            list.add(ContactMatch(id = id, name = name, phoneNumber = number))
                        }
                    }
                }
            }
        }.onFailure { Log.e(TAG, "Failed loading contacts", it) }
        list
    }

    suspend fun callContactByQuery(queryName: String): CommandExecutionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return CommandExecutionResult(
                spokenReplyBn = "কন্টাক্টে কল করতে হলে কন্টাক্টস অনুমতি দিতে হবে। সেটআপ ট্যাব থেকে অনুমতি দিন।",
                actionBadge = "Permission Needed",
                isError = true
            )
        }

        val cleanQuery = queryName.trim()
        val contacts = loadSavedContacts(limit = 500)
        if (contacts.isEmpty()) {
            return CommandExecutionResult(
                spokenReplyBn = "আপনার ফোনে কোনো সেভ করা কন্টাক্ট পাওয়া যায়নি।",
                isError = true
            )
        }

        val match = findBestContactMatch(cleanQuery, contacts)
        if (match == null) {
            return CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, '$cleanQuery' নামে কোনো কন্টাক্ট খুঁজে পাওয়া যায়নি।",
                isError = true
            )
        }

        return callSpecificContact(match)
    }

    fun callSpecificContact(contact: ContactMatch): CommandExecutionResult {
        val cleanNumber = contact.phoneNumber.trim()
        val hasCallPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        return try {
            val action = if (hasCallPermission) Intent.ACTION_CALL else Intent.ACTION_DIAL
            val intent = Intent(action, Uri.parse("tel:${Uri.encode(cleanNumber)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val reply = if (hasCallPermission) {
                "${contact.name}-কে কল করছি।"
            } else {
                "${contact.name}-এর নম্বর ডায়ালারে খুলে দিয়েছি। সরাসরি কল করতে কল অনুমতি দিন।"
            }
            CommandExecutionResult(
                spokenReplyBn = reply,
                actionBadge = if (hasCallPermission) "Calling ${contact.name}" else "Dial ${contact.name}"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed initiating call", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, ${contact.name}-কে কল করা সম্ভব হয়নি।",
                isError = true
            )
        }
    }

    suspend fun lookupCallerName(phoneNumber: String?): String? = withContext(Dispatchers.IO) {
        if (phoneNumber.isNullOrBlank()) return@withContext null
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return@withContext null
        }
        runCatching {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber)
            )
            context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(0)
                } else {
                    null
                }
            }
        }.getOrNull()
    }

    @SuppressLint("MissingPermission")
    fun answerIncomingCall(): CommandExecutionResult {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return CommandExecutionResult(
                spokenReplyBn = "অটো কল রিসিভ করার জন্য Android 8 বা তার উপরের সংস্করণ প্রয়োজন।",
                isError = true
            )
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return CommandExecutionResult(
                spokenReplyBn = "কল রিসিভ করতে ফোন ও কল সহায়তা অনুমতি প্রয়োজন।",
                isError = true
            )
        }
        return try {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            @Suppress("DEPRECATION")
            telecom?.acceptRingingCall()
            CommandExecutionResult(
                spokenReplyBn = "কল রিসিভ করছি।",
                actionBadge = "Call Answered"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed answering call", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, কল রিসিভ করা যায়নি।",
                isError = true
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun declineIncomingCall(): CommandExecutionResult {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return CommandExecutionResult(
                spokenReplyBn = "ভয়েসে কল কাটার জন্য Android 9 বা তার উপরের সংস্করণ প্রয়োজন।",
                isError = true
            )
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return CommandExecutionResult(
                spokenReplyBn = "কল কাটতে ফোন ও কল সহায়তা অনুমতি প্রয়োজন।",
                isError = true
            )
        }
        return try {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            @Suppress("DEPRECATION")
            val ended = telecom?.endCall() == true
            if (ended) {
                CommandExecutionResult(
                    spokenReplyBn = "কল কেটে দিয়েছি।",
                    actionBadge = "Call Declined"
                )
            } else {
                CommandExecutionResult(
                    spokenReplyBn = "বর্তমানে কোনো ইনকামিং কল সক্রিয় নেই।",
                    isError = true
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed ending call", e)
            CommandExecutionResult(
                spokenReplyBn = "দুঃখিত, কল কাটা যায়নি।",
                isError = true
            )
        }
    }

    fun findBestContactMatch(query: String, contacts: List<ContactMatch>): ContactMatch? {
        val normalizedQuery = normalizeName(query)
        val transliteratedQuery = transliterateBengaliToLatin(normalizedQuery)

        // 1. Exact match
        contacts.firstOrNull { normalizeName(it.name) == normalizedQuery }?.let { return it }
        // 2. StartsWith / Contains direct
        contacts.firstOrNull { normalizeName(it.name).contains(normalizedQuery) }?.let { return it }
        // 3. Transliterated Bengali -> Latin match (e.g. "আব্বু" -> "abbu")
        if (transliteratedQuery.isNotBlank()) {
            contacts.firstOrNull {
                val contactLower = normalizeName(it.name)
                contactLower == transliteratedQuery || contactLower.contains(transliteratedQuery)
            }?.let { return it }
        }
        // 4. Token overlap
        val queryTokens = (normalizedQuery.split(" ") + transliteratedQuery.split(" "))
            .filter { it.length >= 2 }
        return contacts.firstOrNull { contact ->
            val nameLower = normalizeName(contact.name)
            queryTokens.any { token -> nameLower.contains(token) }
        }
    }

    private fun normalizeName(input: String): String {
        return input.lowercase(Locale.ROOT)
            .replace(Regex("[-_.,'\"!?]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
            .replace("ডট কম", ".com")
            .replace("ডট অর্গ", ".org")
            .replace("ডট নেট", ".net")
            .replace("ডট বিডি", ".com.bd")
            .replace(" dot ", ".")
            .replace(" ", "")
        return if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            trimmed
        } else {
            "https://$trimmed"
        }
    }

    private fun transliterateBengaliToLatin(text: String): String {
        val map = mapOf(
            'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "ee", 'উ' to "u", 'ঊ' to "oo",
            'এ' to "e", 'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou",
            'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh", 'ঙ' to "ng",
            'চ' to "ch", 'ছ' to "chh", 'জ' to "j", 'ঝ' to "jh", 'ঞ' to "n",
            'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh", 'ণ' to "n",
            'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh", 'ন' to "n",
            'প' to "p", 'ফ' to "f", 'ব' to "b", 'ভ' to "bh", 'ম' to "m",
            'য' to "j", 'র' to "r", 'ল' to "l", 'শ' to "sh", 'ষ' to "sh",
            'স' to "s", 'হ' to "h", 'ড়' to "r", 'ঢ়' to "rh", 'য়' to "y",
            'া' to "a", 'ি' to "i", 'ী' to "i", 'ু' to "u", 'ূ' to "u",
            'ে' to "e", 'ৈ' to "oi", 'ো' to "o", 'ৌ' to "ou",
            'ং' to "ng", 'ঃ' to "h", 'ঁ' to "", '্' to ""
        )
        val sb = StringBuilder()
        for (ch in text) {
            sb.append(map[ch] ?: ch)
        }
        return sb.toString()
    }

    fun cleanup() {
        runCatching { cameraManager?.unregisterTorchCallback(torchCallback) }
    }
}
